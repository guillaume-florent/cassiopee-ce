#ifndef _EIKONAL_HPP_
# define _EIKONAL_HPP_

using isSourcePtr = bool (*) ( double x, double y, double z );
using speedFctPtr = double (*) ( double x, double y, double z );

/*
  Définition grille :
     ( lbx, lby, lbz ) : Coordonnée coin gauche de la grille
     h : Pas d'espace ( le même en x, y et z )
     ( ni, nj, nk )    : Nombre de noeuds dans chaque direction

  Définition de l'équation Eikonal :
     isSrc : Dit si un noeud de la grille est un noeud source ou non
     speed : Fonction de vitesse de l'équation ( = 1 si uniquement distance cartésienne )

  Sortie :
     sol  : solution sous la forme : grid[i+ni*(j+k*nk)]
*/
void solveEikonalOnIsotropGrid( unsigned ni, unsigned nj, unsigned nk,
				double lbx, double lby, double lbz,
				double h,
				isSourcePtr isSrc,
				speedFctPtr speed,
				double* sol );
/*
  Same algo as above but with block approach and OpenMP instructions
  niBlk, njBlk and nkBlk give the size of a block for cache optimization
*/
void blockFIM( unsigned ni, unsigned nj, unsigned nk,
	       double lbx, double lby, double lbz,
	       double h,
	       unsigned niBlk, unsigned njBlk, unsigned nkBlk,
	       unsigned nbSubIter,
	       isSourcePtr isSrc,
	       speedFctPtr speed,
	       double* sol );
#endif
